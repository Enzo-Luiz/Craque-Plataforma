# Craque Platformer

Jogo de plataforma 2D de rolagem lateral, no estilo clássico de Mario Bros, feito com **HTML5 Canvas e JavaScript puro** (sem bibliotecas). O herói é um craque de futebol brasileiro e a fase se passa no Rio de Janeiro: chão de calçadão em ondas e fundo com Pão de Açúcar, Corcovado e a orla.

## Como jogar

| Tecla | Ação |
| --- | --- |
| Setas ou A / D | Andar |
| Espaço, seta para cima ou W | Pular (segure para pular mais alto) |
| Shift | Correr |
| R | Reiniciar a fase |

- Colete os **reais** (moedas) espalhados pela fase.
- Pise nos inimigos para derrotá-los; tocar neles pelo lado tira uma vida.
- Você tem 3 vidas. Cair num buraco também tira uma.
- Chegue à bandeira no fim da fase para vencer.

## Como rodar

Abra o arquivo `index.html` no navegador. Se preferir um servidor local:

```bash
python3 -m http.server 8000
```

e acesse `http://localhost:8000`.

## Como publicar no GitHub

```bash
git init
git add .
git commit -m "Primeira versão do jogo"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/craque-plataforma.git
git push -u origin main
```

Para deixar o jogo jogável online com o GitHub Pages: no repositório, vá em **Settings > Pages**, escolha **Deploy from a branch**, selecione a branch `main` e a pasta `/ (root)`. O jogo ficará em `https://SEU-USUARIO.github.io/craque-plataforma/`.

## Estrutura

```
craque-plataforma/
├── index.html          página do jogo
├── css/style.css       estilo da página
├── js/game.js          lógica, física, desenho e fase
├── assets/
│   ├── sprites-heroi.png   quadros do herói (parado, andando, correndo, pulando)
│   └── moeda-real.png      moeda
└── README.md
```

O fundo do Rio e o chão de calçadão são desenhados por código em `js/game.js`. O nome exibido do herói está na constante `NOME_HEROI`.

## Roadmap

- [x] **Marco 1:** base jogável (andar, correr, pular, colisão, câmera)
- [ ] **Marco 2:** moedas, inimigo, vidas e bandeira de chegada prontos; falta o bloco de interrogação
- [ ] **Marco 3:** sprites do inimigo e dos itens, som, telas de início e fim, segunda fase

## Créditos

Código do jogo e arte do herói e da moeda criados pelo autor do projeto.
