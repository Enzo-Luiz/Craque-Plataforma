const T=32,W=640,H=384,COLS=90,ROWS=12;
const cv=document.getElementById('c'),x=cv.getContext('2d');x.scale(2,2);x.imageSmoothingQuality='high';
// mapa: 0 vazio, 1 chão com grama, 2 terra, 3 plataforma
const g=Array.from({length:ROWS},()=>Array(COLS).fill(0));
const fill=(r,a,b,v)=>{for(let c=a;c<=b;c++)g[r][c]=v};
[[0,24],[28,45],[50,70],[74,89]].forEach(([a,b])=>{fill(10,a,b,1);fill(11,a,b,2)});
fill(7,10,13,3);fill(7,31,34,3);fill(8,37,39,3);fill(5,41,44,3);fill(7,53,56,3);fill(8,76,79,3);
for(let i=0;i<4;i++)for(let r=9-i;r<=9;r++)g[r][62+i]=1;

const NOME_HEROI='Craque';
const SPR={"parado":[{"x":0,"y":0,"w":59,"h":116}],"andando":[{"x":61,"y":0,"w":60,"h":113},{"x":123,"y":0,"w":61,"h":112},{"x":186,"y":0,"w":61,"h":112},{"x":249,"y":0,"w":61,"h":113}],"correndo":[{"x":312,"y":0,"w":70,"h":105},{"x":384,"y":0,"w":75,"h":106},{"x":461,"y":0,"w":79,"h":104},{"x":542,"y":0,"w":80,"h":103}],"pulando":[{"x":624,"y":0,"w":60,"h":83},{"x":686,"y":0,"w":57,"h":97},{"x":745,"y":0,"w":73,"h":94},{"x":820,"y":0,"w":59,"h":81}]};
const img=new Image();img.src='assets/sprites-heroi.png';
const keys={};
addEventListener('keydown',e=>{keys[e.code]=true;if(/^(Space|Arrow)/.test(e.code))e.preventDefault();if(e.code==='KeyR')restart()});
addEventListener('keyup',e=>keys[e.code]=false);
cv.addEventListener('pointerdown',()=>cv.focus());

const CL=[[5,9],[6,9],[7,9],[10,6],[11,6],[12,6],[13,6],[25,8],[26,7],[27,8],[30,9],[31,6],[32,6],[33,6],[34,6],[37,7],[38,7],[39,7],[41,4],[42,4],[43,4],[44,4],[46,8],[47,7],[48,7],[49,8],[53,6],[54,6],[55,6],[56,6],[58,9],[59,9],[60,9],[62,8],[63,7],[64,6],[65,5],[71,8],[72,7],[73,8],[76,7],[77,7],[78,7],[79,7],[82,9],[83,9],[84,9]];
const coins=CL.map(([c,r])=>({x:c*T+16,y:r*T+16,got:false}));let score=0,lives=3,inv=0,over=0,won=0;
const SP=[16,22,32,40,52,58,67,80];
const FX=86*T+12;
const mk=c=>({x:c*T,y:10*T-24,w:26,h:24,vx:-0.8,dead:0});let EN=SP.map(mk);
const coinImg=new Image();coinImg.src='assets/moeda-real.png';
const p={};let cam=0,walk=0;
function reset(){Object.assign(p,{x:64,y:200,w:22,h:50,vx:0,vy:0,ground:false,face:1,coyote:0,buf:0,held:false,jt:99});cam=0}
reset();
function restart(){reset();coins.forEach(k=>k.got=false);score=0;lives=3;inv=0;won=0;EN=SP.map(mk)}
function hurt(){if(won)return;lives--;inv=90;if(lives<=0){restart();over=120;inv=60}else reset()}
function stepEnemies(){for(const e of EN){if(e.dead){e.dead++;continue}
  const fx=e.vx>0?e.x+e.w+e.vx:e.x+e.vx,fc=Math.floor(fx/T),mr=Math.floor((e.y+e.h/2)/T),br=Math.floor((e.y+e.h+2)/T);
  if(solid(fc,mr)||!solid(fc,br))e.vx=-e.vx;else e.x+=e.vx}}
const solid=(c,r)=>(c<0||c>=COLS)?true:(r<0||r>=ROWS)?false:g[r][c]>0;
function hit(){
  const c0=Math.floor(p.x/T),c1=Math.floor((p.x+p.w-0.01)/T),r0=Math.floor(p.y/T),r1=Math.floor((p.y+p.h-0.01)/T);
  for(let r=r0;r<=r1;r++)for(let c=c0;c<=c1;c++)if(solid(c,r))return{c,r};
  return null;
}
function step(){
  const K=won?{}:keys,run=K.ShiftLeft||K.ShiftRight,max=run?5:3.2;
  const dir=(K.ArrowRight||K.KeyD?1:0)-(K.ArrowLeft||K.KeyA?1:0);
  if(dir){p.vx+=dir*(p.ground?0.4:0.28);p.face=dir}
  else{const f=p.ground?0.35:0.05;p.vx=Math.abs(p.vx)<f?0:p.vx-Math.sign(p.vx)*f}
  p.vx=Math.max(-max,Math.min(max,p.vx));p.run=Math.abs(p.vx)>3.4;
  const jk=K.Space||K.ArrowUp||K.KeyW;
  if(jk&&!p.held)p.buf=6;p.held=!!jk;
  if(p.buf>0)p.buf--;
  p.coyote=p.ground?6:Math.max(0,p.coyote-1);
  p.jt++;if(p.buf>0&&p.coyote>0){p.vy=-12.2;p.buf=0;p.coyote=0;p.jt=0}
  if(!jk&&p.vy<-4)p.vy=-4;
  p.vy=Math.min(p.vy+0.6,14);
  p.x+=p.vx;
  let h=hit();
  if(h){if(p.vx>0)p.x=h.c*T-p.w;else p.x=(h.c+1)*T;p.vx=0}
  p.y+=p.vy;p.ground=false;
  h=hit();
  if(h){if(p.vy>0){p.y=h.r*T-p.h;p.ground=true}else p.y=(h.r+1)*T;p.vy=0}
  if(p.y>H+120)hurt();
  for(const k of coins)if(!k.got&&Math.abs(k.x-(p.x+p.w/2))<11+p.w/2&&Math.abs(k.y-(p.y+p.h/2))<11+p.h/2){k.got=true;score++}
  if(p.ground)walk+=Math.abs(p.vx)*0.07;
  stepEnemies();
  if(inv>0)inv--;if(over>0)over--;
  if(won)won++;else if(p.x+p.w>FX&&p.x<FX+6&&p.y<320&&p.y+p.h>128)won=1;
  for(const e of EN){if(e.dead)continue;
    if(p.x<e.x+e.w&&p.x+p.w>e.x&&p.y<e.y+e.h&&p.y+p.h>e.y){
      if(p.vy>0.5&&p.y+p.h-e.y<24){e.dead=1;p.vy=(keys.Space||keys.ArrowUp||keys.KeyW)?-11:-7;p.ground=false}
      else if(inv<=0){hurt();break}}}
  const target=Math.max(0,Math.min(COLS*T-W,p.x+p.w/2-W/2+p.face*30));
  cam+=(target-cam)*0.12;
}
function rect(c,a,b,w,h){x.fillStyle=c;x.fillRect(Math.round(a),Math.round(b),w,h)}
function rng(s){return()=>{s=(s*16807)%2147483647;return(s-1)/2147483646}}
function layer(w,h,fn){const c=document.createElement('canvas');c.width=w*2;c.height=h*2;const k=c.getContext('2d');k.scale(2,2);fn(k,w,h);return c}
function mound(k,x0,x1,top,base,fill){k.fillStyle=fill;k.beginPath();k.moveTo(x0,base);k.bezierCurveTo(x0+(x1-x0)*.22,top,x0+(x1-x0)*.78,top,x1,base);k.closePath();k.fill()}
function palm(k,px,base,hgt,R){
  const lean=(R()-.5)*18,tx=px+lean,ty=base-hgt;
  k.lineCap='round';k.strokeStyle='#6b4a2b';k.lineWidth=4;
  k.beginPath();k.moveTo(px,base);k.quadraticCurveTo(px+lean*.3,base-hgt*.5,tx,ty);k.stroke();
  k.strokeStyle='#1f7a3a';k.lineWidth=2.5;
  for(let a=0;a<7;a++){const ang=-Math.PI+a*Math.PI/6+(R()-.5)*.2,len=22+R()*8;
    k.beginPath();k.moveTo(tx,ty);k.quadraticCurveTo(tx+Math.cos(ang)*len*.6,ty+Math.sin(ang)*len*.6-8,tx+Math.cos(ang)*len,ty+Math.sin(ang)*len+6);k.stroke()}
  k.fillStyle='#5a3b20';k.beginPath();k.arc(tx,ty+1,2.5,0,6.283);k.fill();
}
// fundo distante: céu, mar, Pão de Açúcar e Corcovado com o Cristo
const FAR=layer(1000,320,(k,w,h)=>{
  let gr=k.createLinearGradient(0,0,0,h);
  gr.addColorStop(0,'#2f8fe0');gr.addColorStop(.55,'#8fd0f7');gr.addColorStop(.75,'#d9f0fb');gr.addColorStop(1,'#ffeccb');
  k.fillStyle=gr;k.fillRect(0,0,w,h);
  gr=k.createRadialGradient(830,62,0,830,62,80);gr.addColorStop(0,'rgba(255,248,210,.95)');gr.addColorStop(1,'rgba(255,248,210,0)');
  k.fillStyle=gr;k.fillRect(700,0,260,170);
  k.fillStyle='rgba(255,255,255,.85)';
  [[120,56,1],[430,36,.8],[640,92,1.1],[930,40,.9]].forEach(([cx,cy,sc])=>[[0,0,34,12],[-26,5,24,9],[28,6,26,9],[6,-7,22,9]].forEach(([dx,dy,rx,ry])=>{k.beginPath();k.ellipse(cx+dx*sc,cy+dy*sc,rx*sc,ry*sc,0,0,6.283);k.fill()}));
  gr=k.createLinearGradient(0,214,0,h);gr.addColorStop(0,'#46b4d2');gr.addColorStop(1,'#0e6f9b');k.fillStyle=gr;k.fillRect(0,214,w,h-214);
  const R=rng(3);k.strokeStyle='rgba(255,255,255,.45)';k.lineWidth=1;
  for(let i=0;i<70;i++){const sx=R()*w,sy=218+R()*60;k.beginPath();k.moveTo(sx,sy);k.lineTo(sx+4+R()*8,sy);k.stroke()}
  mound(k,-80,200,140,262,'#5aa57a');mound(k,820,1120,130,262,'#5aa57a');
  const pa=()=>{k.beginPath();k.moveTo(270,252);k.bezierCurveTo(272,150,300,105,335,105);k.bezierCurveTo(372,105,392,170,396,252);k.closePath()};
  gr=k.createLinearGradient(270,0,395,0);gr.addColorStop(0,'#aeb3b8');gr.addColorStop(1,'#757b82');pa();k.fillStyle=gr;k.fill();
  gr=k.createLinearGradient(0,170,0,252);gr.addColorStop(0,'rgba(55,125,70,0)');gr.addColorStop(1,'rgba(45,110,60,.95)');pa();k.fillStyle=gr;k.fill();
  gr=k.createLinearGradient(0,190,0,252);gr.addColorStop(0,'#9aa0a5');gr.addColorStop(.45,'#6f8f6e');gr.addColorStop(1,'#2f7a46');
  k.fillStyle=gr;k.beginPath();k.moveTo(165,252);k.bezierCurveTo(170,206,198,190,225,190);k.bezierCurveTo(255,190,272,214,278,252);k.closePath();k.fill();
  k.strokeStyle='#2b2b2b';k.lineWidth=.8;k.beginPath();k.moveTo(225,190);k.lineTo(335,106);k.stroke();
  k.fillStyle='#d62828';k.fillRect(282,144,7,5);
  const cm=()=>{k.beginPath();k.moveTo(470,262);k.bezierCurveTo(520,200,565,118,622,84);k.bezierCurveTo(642,72,668,68,688,80);k.bezierCurveTo(745,112,805,190,865,262);k.closePath()};
  gr=k.createLinearGradient(0,68,0,262);gr.addColorStop(0,'#3f9a5c');gr.addColorStop(1,'#1f5f3a');cm();k.fillStyle=gr;k.fill();
  gr=k.createLinearGradient(560,0,860,0);gr.addColorStop(0,'rgba(0,40,20,0)');gr.addColorStop(1,'rgba(0,40,20,.4)');cm();k.fillStyle=gr;k.fill();
  k.save();k.translate(661,72);k.fillStyle='#f4f1e8';k.fillRect(-5,-8,10,8);k.fillRect(-2,-27,4,20);k.fillRect(-11,-24,22,3.2);k.beginPath();k.arc(0,-30,3,0,6.283);k.fill();k.restore();
  gr=k.createLinearGradient(0,170,0,262);gr.addColorStop(0,'rgba(255,240,210,0)');gr.addColorStop(1,'rgba(255,240,210,.45)');k.fillStyle=gr;k.fillRect(0,170,w,92);
});
// fundo próximo: prédios da orla e coqueiros
const NEAR=layer(1560,320,(k,w,h)=>{
  const R=rng(11),pal=[['#f4efe6','#d9d2c4'],['#f6d9c4','#d8b399'],['#cfe3ee','#a8c4d4'],['#f3e3a8','#d4c07f'],['#e9e9ee','#c4c4cf'],['#f0c7c0','#d19f98']];
  let bx=-10;
  while(bx<w){
    if(R()<.22){bx+=22+R()*34;continue}
    const bw=34+R()*40,top=205+R()*60,c=pal[Math.floor(R()*pal.length)],gr=k.createLinearGradient(bx,0,bx+bw,0);
    gr.addColorStop(0,c[0]);gr.addColorStop(1,c[1]);k.fillStyle=gr;k.fillRect(bx,top,bw,h-top);
    k.fillStyle='rgba(40,70,100,.4)';
    for(let wy=top+9;wy<h-14;wy+=9)for(let wx=bx+5;wx<bx+bw-7;wx+=9)k.fillRect(wx,wy,5,5);
    k.fillStyle='rgba(0,0,0,.14)';k.fillRect(bx,top,bw,3);
    if(R()<.4){k.fillStyle='#8a8f96';k.fillRect(bx+bw*.4,top-8,2,8)}
    bx+=bw+R()*5;
  }
  for(let px=40;px<w;px+=110+R()*90)palm(k,px,322,70+R()*40,R);
});
// textura do calçadão de ondas (pedra portuguesa preta e branca)
const GT=(()=>{const c=document.createElement('canvas');c.width=c.height=128;const k=c.getContext('2d',{willReadFrequently:true});
  const im=k.createImageData(128,128),R=rng(5),tab=Array.from({length:1024},()=>R());
  for(let y=0;y<128;y++)for(let X=0;X<128;X++){
    const ph=y/128*2+.3*Math.sin(X/128*6.2832),dark=(ph-Math.floor(ph))<.5,n=(tab[(y>>2)*32+(X>>2)]-.5)*30,v=dark?42+n:226+n,i=(y*128+X)*4;
    im.data[i]=im.data[i+1]=v;im.data[i+2]=v+(dark?6:0);im.data[i+3]=255}
  k.putImageData(im,0,0);k.lineWidth=1;
  for(let i=0;i<420;i++){const x0=4+R()*120,y0=4+R()*120,a=R()*6.283,l=3+R()*4,pv=k.getImageData(x0|0,y0|0,1,1).data[0];
    k.strokeStyle=pv<120?'rgba(150,150,150,.35)':'rgba(70,70,70,.35)';k.beginPath();k.moveTo(x0,y0);k.lineTo(x0+Math.cos(a)*l,y0+Math.sin(a)*l);k.stroke()}
  return c})();
function draw(){
  const sky=x.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#4aa8f0');sky.addColorStop(1,'#bfe6ff');
  x.fillStyle=sky;x.fillRect(0,0,W,H);
  // fundo: Rio de Janeiro (vetorial) em paralaxe
  x.drawImage(FAR,Math.round(-cam*0.15),0,1000,320);
  x.fillStyle='#14232d';x.fillRect(0,320,W,H-320);
  x.drawImage(NEAR,Math.round(-cam*0.4),0,1560,320);
  // chão: calçadão de ondas de Copacabana
  const c0=Math.floor(cam/T),c1=Math.min(COLS-1,c0+Math.ceil(W/T)+1);
  for(let r=0;r<ROWS;r++)for(let c=c0;c<=c1;c++){
    const v=g[r][c];if(!v)continue;const tx=Math.round(c*T-cam),ty=r*T;
    x.drawImage(GT,((c*T)%64)*2,((r*T)%64)*2,64,64,tx,ty,T,T);
    if(!solid(c,r-1))rect('#1b1b1b',tx,ty,T,3);
    if(v===3)rect('#1b1b1b',tx,ty+T-2,T,2);
    if(!solid(c-1,r))rect('#1b1b1b',tx,ty,2,T);
    if(!solid(c+1,r))rect('#1b1b1b',tx+T-2,ty,2,T);
  }
  // moedas (reais)
  const tt=performance.now()/1000;
  for(const k of coins){if(k.got)continue;const sx=k.x-cam;if(sx<-20||sx>W+20)continue;
    const bob=Math.sin(tt*2+k.x*0.1)*3;
    if(coinImg.complete)x.drawImage(coinImg,sx-11,k.y-11+bob,22,22)}
  // bandeira de chegada
  const bx=FX-cam;
  if(bx>-60&&bx<W+60){rect('#6b6f73',bx-6,312,18,8);rect('#cfd6dc',bx,128,6,192);rect('#f2c200',bx-2,120,10,10);
    const cy=136+(won?Math.min(won,70)/70*140:0);
    rect('#1f9d3a',bx-32,cy,32,22);rect('#f2c200',bx-24,cy+4,16,14);rect('#1b4fb5',bx-20,cy+8,8,6)}
  // inimigos (forma simples)
  for(const e of EN){const sx=e.x-cam;if(sx<-40||sx>W+40)continue;
    if(e.dead){if(e.dead<30){rect('#8b4a2b',sx,e.y+e.h-8,e.w,8);rect('#f2dcc0',sx+4,e.y+e.h-5,18,3)}continue}
    const f=Math.floor(tt*6)%2;
    rect('#8b4a2b',sx+3,e.y,20,14);rect('#8b4a2b',sx,e.y+6,26,10);
    rect('#f2dcc0',sx+4,e.y+14,18,6);
    rect('#2a160b',sx+(f?2:6),e.y+20,8,4);rect('#2a160b',sx+(f?16:12),e.y+20,8,4);
    rect('#fff',sx+5,e.y+7,6,6);rect('#fff',sx+15,e.y+7,6,6);
    rect('#111',sx+(e.vx>0?8:5),e.y+9,3,4);rect('#111',sx+(e.vx>0?18:15),e.y+9,3,4);
    rect('#2a160b',sx+4,e.y+5,8,2);rect('#2a160b',sx+14,e.y+5,8,2)}
  // jogador (sprites)
  let an,fi=0;
  if(!p.ground){an='pulando';fi=p.jt<5?0:p.vy<-6?1:p.vy<2?2:3}
  else if(Math.abs(p.vx)>0.25){an=p.run?'correndo':'andando';fi=Math.floor(walk)%4}
  else an='parado';
  const fr=SPR[an][fi],dw=fr.w/2,dh=fr.h/2;
  x.save();x.translate(Math.round(p.x-cam+p.w/2),Math.round(p.y+p.h+1));
  if(p.face<0)x.scale(-1,1);if(inv>0&&Math.floor(inv/4)%2)x.globalAlpha=0.35;
  if(img.complete)x.drawImage(img,fr.x,fr.y,fr.w,fr.h,-dw/2,-dh,dw,dh);
  x.restore();
  // HUD
  x.fillStyle='#00000066';x.fillRect(8,8,210,26);x.fillStyle='#fff';x.font='bold 14px Trebuchet MS, sans-serif';
  x.fillText(NOME_HEROI+' – Marco 1',16,26);
  x.fillStyle='#00000066';x.fillRect(W-118,8,110,26);
  if(coinImg.complete)x.drawImage(coinImg,W-112,10,22,22);
  x.fillStyle='#fff';x.fillText('Reais: '+score,W-84,26);
  x.fillStyle='#00000066';x.fillRect(8,38,110,26);x.fillStyle='#fff';x.fillText('Vidas: '+lives,16,56);
  if(won>40){x.fillStyle='#000b';x.fillRect(0,H/2-60,W,120);x.fillStyle='#fff';x.textAlign='center';x.font='bold 30px Trebuchet MS, sans-serif';x.fillText('Fase concluída!',W/2,H/2-14);x.font='16px Trebuchet MS, sans-serif';x.fillText('Reais coletados: '+score+' de '+coins.length,W/2,H/2+14);x.fillText('Aperte R para jogar de novo',W/2,H/2+40);x.textAlign='left'}
  if(over>0){x.fillStyle='#000a';x.fillRect(0,H/2-32,W,64);x.fillStyle='#fff';x.font='bold 28px Trebuchet MS, sans-serif';x.textAlign='center';x.fillText('Fim de jogo, recomeçando',W/2,H/2+10);x.textAlign='left'}
}
let last=performance.now(),acc=0;
function loop(t){acc+=Math.min(100,t-last);last=t;while(acc>=1000/60){step();acc-=1000/60}draw();requestAnimationFrame(loop)}
requestAnimationFrame(loop);
